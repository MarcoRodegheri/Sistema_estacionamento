package PUCRS_Estacionamento.TF;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Estacionado {
    private String placa;
    private LocalDateTime chegada;

    public Estacionado(String placa, LocalDateTime chegada) {
        this.placa = placa;
        this.chegada = chegada;
    }

    public String getPlaca() {
        return placa;
    }

    public String getChegadaFormatada() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
        return chegada.format(formatter);
    }
    
    public LocalDateTime getChegada() {
        return chegada;
    }
}