package PUCRS_Estacionamento.TF;

import com.vaadin.flow.component.Key;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.button.ButtonVariant;
import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.html.H2;
import com.vaadin.flow.component.html.Hr;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.notification.Notification;
import com.vaadin.flow.component.notification.NotificationVariant;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.router.RouterLink;

@PageTitle("Operação do Estacionamento")
@Route("operacao")
public class OperacaoView extends VerticalLayout {

    private final ServicoDeEstacionamento servico = ServicoDeEstacionamento.getInstance();

    private final TextField placaField;
    private final Grid<Estacionado> gridCarrosEstacionados;

    public OperacaoView() {
        add(new H2("Operação do Estacionamento (Entrada/Saída)"));

        placaField = new TextField("Placa do Veículo");
        placaField.setPlaceholder("ABC1D23");

        Button btnEntrada = new Button("Registrar Entrada", VaadinIcon.SIGN_IN.create());
        btnEntrada.addThemeVariants(ButtonVariant.LUMO_PRIMARY);
        btnEntrada.addClickShortcut(Key.ENTER);
        btnEntrada.addClickListener(e -> registrarEntrada());

        Button btnSaida = new Button("Registrar Saída", VaadinIcon.SIGN_OUT.create());
        btnSaida.addThemeVariants(ButtonVariant.LUMO_ERROR);
        btnSaida.addClickListener(e -> registrarSaida());

        HorizontalLayout botoesLayout = new HorizontalLayout(btnEntrada, btnSaida);
        botoesLayout.setAlignItems(Alignment.BASELINE);

        gridCarrosEstacionados = new Grid<>(Estacionado.class);
        gridCarrosEstacionados.setColumns("placa", "chegadaFormatada");
        gridCarrosEstacionados.getColumnByKey("chegadaFormatada").setHeader("Horário de Chegada");
        
        atualizarGrid();

        add(placaField, botoesLayout, new H2("Carros Estacionados Agora"), gridCarrosEstacionados);
        add(new Hr(), new RouterLink("Voltar ao Menu", MainView.class));
        
        setPadding(true);
    }

    private void registrarEntrada() {
        String placa = placaField.getValue().toUpperCase().trim();
        if (placa.isEmpty()) {
            notificar("Por favor, digite uma placa.", true);
            return;
        }

        String resultado = servico.registrarEntrada(placa);
        
        if (resultado.startsWith("Erro") || resultado.startsWith("Acesso negado")) {
            notificar(resultado, true);
        } else {
            notificar(resultado, false);
            placaField.clear();
            atualizarGrid();
        }
    }

    private void registrarSaida() {
        String placa = placaField.getValue().toUpperCase().trim();
        if (placa.isEmpty()) {
            notificar("Por favor, digite uma placa.", true);
            return;
        }
        
        String resultado = servico.registrarSaida(placa);

        if (resultado.startsWith("Erro")) {
            notificar(resultado, true);
        } else {
            notificar(resultado, false);
            placaField.clear();
            atualizarGrid();
        }
    }

    private void atualizarGrid() {
        gridCarrosEstacionados.setItems(servico.getCarrosEstacionados());
    }

    private void notificar(String mensagem, boolean erro) {
        Notification notification = Notification.show(mensagem, 5000, Notification.Position.TOP_CENTER);
        if (erro) {
            notification.addThemeVariants(NotificationVariant.LUMO_ERROR);
        } else {
            notification.addThemeVariants(NotificationVariant.LUMO_SUCCESS);
        }
    }
}