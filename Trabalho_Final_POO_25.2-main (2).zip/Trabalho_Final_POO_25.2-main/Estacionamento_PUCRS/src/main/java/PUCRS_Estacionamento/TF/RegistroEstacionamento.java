package PUCRS_Estacionamento.TF;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class RegistroEstacionamento {
    
    public Cliente cliente;
    public String placa;
    public LocalDateTime chegada;
    public LocalDateTime saida;
    
    public RegistroEstacionamento(Cliente cliente, String placa, LocalDateTime chegada, LocalDateTime saida) {
        this.cliente = cliente;
        this.placa = placa;
        this.chegada = chegada;
        this.saida = saida;
    }

    public String getCpfCliente() {
        return cliente.getCpf();
    }
    
    public String getNomeCliente() {
        return cliente.getNome();
    }

    public String getTipoCliente() {
        return cliente.getClass().getSimpleName();
    }

    public String getPlaca() {
        return placa;
    }

    public String getChegadaFormatada() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
        return chegada.format(formatter);
    }
    
    public String getSaidaFormatada() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
        return saida.format(formatter);
    }

    public LocalDateTime getChegada() { return chegada; }
    public LocalDateTime getSaida() { return saida; }
}