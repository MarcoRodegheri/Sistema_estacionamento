package PUCRS_Estacionamento.TF;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
import java.util.stream.Collectors;

public class ServicoDeEstacionamento {

    private static ServicoDeEstacionamento instance;

    public static ServicoDeEstacionamento getInstance() {
        if (instance == null) {
            instance = new ServicoDeEstacionamento();
        }
        return instance;
    }

    private CadastroClientes cc;
    private Map<String, LocalDateTime> entradas;
    private List<RegistroEstacionamento> historico;
    private final int CAPACIDADE_MAXIMA = 500;

    private ServicoDeEstacionamento() {
        try {
            List<Cliente> clientes = CarregadorDados.carregaClientesLista("clientes.csv");
            this.cc = new CadastroClientes(clientes);
            this.entradas = CarregadorDados.carregaDeEntradasMap("entradas.csv");
            this.historico = new ArrayList<>();
        } catch (Exception e) {
            this.cc = new CadastroClientes(new ArrayList<>());
            this.entradas = new HashMap<>();
            this.historico = new ArrayList<>();
        }
    }

    public String registrarEntrada(String placa) {
        LocalDateTime horaEntrada = LocalDateTime.now();

        if (entradas.size() >= CAPACIDADE_MAXIMA) {
            return "Estacionamento lotado.";
        }
        if (entradas.containsKey(placa)) {
            return "Erro: Veículo já está no estacionamento.";
        }
        
        Cliente cliente = cc.getPorPlaca(placa);
        if (cliente == null) {
            return "Erro: Veículo não cadastrado.";
        }
        if (cliente instanceof Estudante) {
            Estudante est = (Estudante) cliente;
            if (est.getCreditos() < -15) {
                return "Acesso negado: Estudante com débito excessivo.";
            }
        }
        
        entradas.put(placa, horaEntrada);
        
        if (cliente instanceof Estudante && ((Estudante) cliente).getCreditos() <= 0) {
            return "Entrada registrada. Aviso: Saldo devedor.";
        }
        return "Entrada registrada.";
    }

    public String registrarSaida(String placa) {
        LocalDateTime horaSaida = LocalDateTime.now();

        if (!entradas.containsKey(placa)) {
            return "Erro: Veículo não consta como estacionado.";
        }

        LocalDateTime horaChegada = entradas.get(placa);
        Cliente cliente = cc.getPorPlaca(placa);
        
        if (cliente == null) { 
            entradas.remove(placa);
            return "Erro: Cliente não encontrado, mas saída registrada.";
        }

        cliente.calculaCusto(horaChegada, horaSaida);

        historico.add(new RegistroEstacionamento(cliente, placa, horaChegada, horaSaida));
        entradas.remove(placa);

        return "Saída registrada para " + cliente.getNome() + ".";
    }

    public boolean adicionarCreditosEstudante(String cpf, int valor) {
        Cliente cliente = cc.getPorCpf(cpf);
        if (cliente instanceof Estudante) {
            return ((Estudante) cliente).adicionaCreditos(valor);
        }
        return false;
    }

    public double getDebitoTecnopuc(String cpf) {
        Cliente cliente = cc.getPorCpf(cpf);
        if (cliente instanceof Tecnopuc) {
            return ((Tecnopuc) cliente).getDebitos();
        }
        return -1;
    }

    public void registrarPagamentoTecnopuc(String cpf, double valorPago) {
        Cliente cliente = cc.getPorCpf(cpf);
        if (cliente instanceof Tecnopuc) {
            ((Tecnopuc) cliente).abateDebito(valorPago);
        }
    }

    public Map<String, Long> relatorioEntradasPorTipo(LocalDateTime inicio, LocalDateTime fim) {
        return historico.stream()
            .filter(reg -> reg.chegada.isAfter(inicio) && reg.chegada.isBefore(fim))
            .collect(Collectors.groupingBy(
                reg -> reg.cliente.getClass().getSimpleName(),
                Collectors.counting()
            ));
    }

    public double relatorioReceitaTotal(int mes, int ano) {
        return historico.stream()
            .filter(reg -> reg.saida.getMonthValue() == mes && reg.saida.getYear() == ano)
            .mapToDouble(reg -> calcularCustoDoRegistro(reg))
            .sum();
    }

    public List<RegistroEstacionamento> relatorioUsoPorUsuario(String cpf, LocalDateTime inicio, LocalDateTime fim) {
        return historico.stream()
            .filter(reg -> reg.cliente.getCpf().equals(cpf))
            .filter(reg -> reg.chegada.isAfter(inicio) && reg.chegada.isBefore(fim))
            .collect(Collectors.toList());
    }

    public Map<String, Double> relatorioReceitaPorTipo(int mes, int ano) {
        return historico.stream()
            .filter(reg -> reg.saida.getMonthValue() == mes && reg.saida.getYear() == ano)
            .collect(Collectors.groupingBy(
                reg -> reg.cliente.getClass().getSimpleName(),
                Collectors.summingDouble(reg -> calcularCustoDoRegistro(reg))
            ));
    }

    public List<String> relatorioPlacasPorDiaSaida(LocalDateTime dia) {
        return historico.stream()
            .filter(reg -> reg.saida.toLocalDate().isEqual(dia.toLocalDate()))
            .map(reg -> reg.placa)
            .distinct()
            .collect(Collectors.toList());
    }

    private double calcularCustoDoRegistro(RegistroEstacionamento reg) {
        long minutos = Duration.between(reg.chegada, reg.saida).toMinutes();
        if (minutos < 15) {
            return 0.0;
        }

        if (reg.cliente instanceof Estudante) {
            return 15.0;
        } else if (reg.cliente instanceof Tecnopuc) {
            double horas = minutos / 60.0;
            return horas * 1.5;
        }
        return 0.0;
    }
    
    public List<Estacionado> getCarrosEstacionados() {
        return entradas.entrySet().stream()
            .map(entry -> new Estacionado(entry.getKey(), entry.getValue()))
            .collect(Collectors.toList());
    }
    
    public List<RegistroEstacionamento> getHistoricoCompleto() {
        return new ArrayList<>(historico);
    }
}