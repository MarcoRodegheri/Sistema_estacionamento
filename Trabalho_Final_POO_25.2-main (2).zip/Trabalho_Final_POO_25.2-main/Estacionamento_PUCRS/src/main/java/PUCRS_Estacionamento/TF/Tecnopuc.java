package PUCRS_Estacionamento.TF;

import java.time.LocalDateTime;
import java.time.Duration;

public class Tecnopuc extends Cliente {

    private double debitos;

    public Tecnopuc(String cpf, String nome, String celular, double debitos) {
        super(cpf, nome, celular);
        this.debitos = debitos;
    }

    public double getDebitos() {
        return this.debitos;
    }

    public double abateDebito(double valor) {
        this.debitos -= valor;
        return this.debitos;
    }

    @Override
    public void cadastraVeiculo(String placa) {
        this.veiculos.add(placa);
    }

    @Override
    public void calculaCusto(LocalDateTime chegada, LocalDateTime saida) {
        long minutos = Duration.between(chegada, saida).toMinutes();

        if (minutos >= 15) {
            double horas = minutos / 60.0;
            double custo = horas * 1.5;
            this.debitos += custo;
        }
    }
}