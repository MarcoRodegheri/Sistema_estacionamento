package PUCRS_Estacionamento.TF;
import java.time.LocalDateTime;

public class Pucrs extends Cliente {

    public Pucrs(String cpf, String nome, String celular) {
        super(cpf, nome, celular);
    }

    @Override
    public void cadastraVeiculo(String placa) {
        if (this.veiculos.size() < 2) {
            this.veiculos.add(placa);
        }
    }

    @Override
    public void calculaCusto(LocalDateTime chegada, LocalDateTime saida) {
    }
}