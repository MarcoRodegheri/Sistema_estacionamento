package PUCRS_Estacionamento.TF;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CadastroClientes {

    private Map<String, Cliente> clientesPorCpf;
    private Map<String, Cliente> clientesPorPlaca;

    public CadastroClientes(List<Cliente> clientes) {
        this.clientesPorCpf = new HashMap<>();
        this.clientesPorPlaca = new HashMap<>();

        for (Cliente cliente : clientes) {
            this.clientesPorCpf.put(cliente.getCpf(), cliente);
            for (String placa : cliente.getVeiculos()) {
                this.clientesPorPlaca.put(placa, cliente);
            }
        }
    }

    public Cliente getPorCpf(String cpf) {
        return clientesPorCpf.get(cpf);
    }

    public Cliente getPorPlaca(String placa) {
        return clientesPorPlaca.get(placa);
    }
}