package PUCRS_Estacionamento.TF;

import java.time.LocalDateTime;
import java.time.Duration;

public class Estudante extends Cliente {

    private int creditos;

    public Estudante(String cpf, String nome, String celular, int creditos) {
        super(cpf, nome, celular);
        this.creditos = creditos;
    }

    public int getCreditos() {
        return this.creditos;
    }

    public boolean adicionaCreditos(int valor) {
        if (valor == 15 || valor == 50 || valor == 100 || valor == 150) {
            this.creditos += valor;
            return true;
        }
        return false;
    }

    @Override
    public void cadastraVeiculo(String placa) {
        if (this.veiculos.size() < 2) {
            this.veiculos.add(placa);
        }
    }
    
    @Override
    public void calculaCusto(LocalDateTime chegada, LocalDateTime saida) {
        long minutos = Duration.between(chegada, saida).toMinutes();

        if (minutos >= 15) {
            this.creditos -= 15;
        }
    }
}