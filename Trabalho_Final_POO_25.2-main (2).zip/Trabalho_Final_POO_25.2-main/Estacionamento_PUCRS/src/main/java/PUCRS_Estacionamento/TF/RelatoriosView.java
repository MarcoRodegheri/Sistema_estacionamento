package PUCRS_Estacionamento.TF;

import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.datepicker.DatePicker;
import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.html.H2;
import com.vaadin.flow.component.html.H3;
import com.vaadin.flow.component.html.Hr;
import com.vaadin.flow.component.notification.Notification;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.router.RouterLink;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@PageTitle("Módulo Gerencial")
@Route("relatorios")
public class RelatoriosView extends VerticalLayout {

    private final ServicoDeEstacionamento servico = ServicoDeEstacionamento.getInstance();
    private final Grid<RegistroEstacionamento> gridHistorico;
    private final DatePicker dataInicio;
    private final DatePicker dataFim;

    public RelatoriosView() {
        add(new H2("Módulo Gerencial (Relatórios)"));

        dataInicio = new DatePicker("Data de Início");
        dataFim = new DatePicker("Data de Fim");

        add(new H3("Relatório de Uso (por Usuário e Data)"));
        TextField cpfUsuario = new TextField("CPF do Usuário (deixe em branco para todos)");
        Button btnFiltrar = new Button("Filtrar Histórico");
        
        gridHistorico = new Grid<>(RegistroEstacionamento.class);
        gridHistorico.setColumns("cpfCliente", "nomeCliente", "tipoCliente", "placa", "chegadaFormatada", "saidaFormatada");
        
        btnFiltrar.addClickListener(e -> filtrarHistorico(cpfUsuario.getValue()));
        
        add(dataInicio, dataFim, cpfUsuario, btnFiltrar, gridHistorico);
        add(new Hr());

        add(new H3("Relatórios de Receita (por Mês/Ano)"));
        TextField mes = new TextField("Mês (1-12)");
        TextField ano = new TextField("Ano (AAAA)");
        Button btnReceita = new Button("Calcular Receita");
        
        btnReceita.addClickListener(e -> {
            try {
                int m = Integer.parseInt(mes.getValue());
                int a = Integer.parseInt(ano.getValue());
                
                double total = servico.relatorioReceitaTotal(m, a);
                Map<String, Double> porTipo = servico.relatorioReceitaPorTipo(m, a);
                
                Notification.show("Receita Total: R$ " + String.format("%.2f", total), 5000, Notification.Position.TOP_CENTER);
                Notification.show("Detalhado: " + porTipo.toString(), 5000, Notification.Position.TOP_CENTER);

            } catch (NumberFormatException ex) {
                Notification.show("Mês e Ano devem ser números válidos.", 3000, Notification.Position.TOP_CENTER);
            }
        });
        
        add(mes, ano, btnReceita);
        add(new Hr(), new RouterLink("Voltar ao Menu", MainView.class));

        gridHistorico.setItems(servico.getHistoricoCompleto());
        
        setPadding(true);
    }
    
    private void filtrarHistorico(String cpf) {
        LocalDateTime inicio = dataInicio.getValue() != null ? dataInicio.getValue().atStartOfDay() : LocalDateTime.MIN;
        LocalDateTime fim = dataFim.getValue() != null ? dataFim.getValue().atTime(LocalTime.MAX) : LocalDateTime.MAX;

        List<RegistroEstacionamento> resultado;

        if (cpf == null || cpf.trim().isEmpty()) {
            resultado = servico.getHistoricoCompleto().stream()
                .filter(reg -> reg.chegada.isAfter(inicio) && reg.chegada.isBefore(fim))
                .collect(Collectors.toList());
            Notification.show("Mostrando " + resultado.size() + " registros no período.");
        } else {
            resultado = servico.relatorioUsoPorUsuario(cpf, inicio, fim);
             Notification.show("Mostrando " + resultado.size() + " registros para o CPF " + cpf);
        }
        
        gridHistorico.setItems(resultado);
    }
}