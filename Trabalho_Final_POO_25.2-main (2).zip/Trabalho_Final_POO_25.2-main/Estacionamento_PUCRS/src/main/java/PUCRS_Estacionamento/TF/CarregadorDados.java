package PUCRS_Estacionamento.TF;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

public class CarregadorDados {

    public static List<Cliente> carregaClientesLista(String nomeArquivo) {
        List<Cliente> clientes = new LinkedList<>();
        try {
            Files.lines(Paths.get(nomeArquivo))
                    .filter(linha -> !linha.trim().isEmpty())
                    .forEach(linha -> {
                        String[] partes = linha.split(",");
                        String cpf = partes[0];
                        String nome = partes[1];
                        String celular = partes[2];
                        Cliente cliente;
                        
                        if (partes[4].equals("Estudante")) {
                            int credito = Integer.parseInt(partes[3]);
                            cliente = new Estudante(cpf, nome, celular, credito);
                            for (int i = 5; i < partes.length; i++) {
                                cliente.cadastraVeiculo(partes[i]);
                            }
                        } 
                        else if (partes[4].equals("Tecnopuc")) {
                            double debito = Double.parseDouble(partes[3]);
                            cliente = new Tecnopuc(cpf, nome, celular, debito);
                            for (int i = 5; i < partes.length; i++) {
                                cliente.cadastraVeiculo(partes[i]);
                            }
                        } 
                        else if (partes[3].equals("Pucrs")) { 
                            cliente = new Pucrs(cpf, nome, celular);
                            for (int i = 4; i < partes.length; i++) { 
                                cliente.cadastraVeiculo(partes[i]);
                            }
                        } else {
                            throw new IllegalArgumentException("Tipo de cliente desconhecido: " + partes[4]);
                        }
                        clientes.add(cliente);
                    });
        } catch (IOException | IllegalArgumentException e) {
            throw new RuntimeException("Erro ao ler arquivo de clientes: " + e.getMessage(), e);
        }
        return clientes;
    }

    public static Map<String, LocalDateTime> carregaDeEntradasMap(String nomeArquivo) {
        Map<String,LocalDateTime> entradasMap = new HashMap<>();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
        try {
            Files.lines(Paths.get(nomeArquivo))
                    .filter(linha -> !linha.trim().isEmpty())
                    .forEach(linha -> {
                        String[] partes = linha.split(",");
                        String placa = partes[0];
                        String data = partes[1];
                        String hora = partes[2];
                        
                        String dataHora = data + " " + hora;
                        LocalDateTime horarioEntrada = LocalDateTime.parse(dataHora, formatter);
                        
                        entradasMap.put(placa, horarioEntrada);
                    });
        } catch (java.io.IOException e) {
            throw new RuntimeException("Erro ao ler arquivo de entradas: " + e.getMessage(), e);
        }
        return entradasMap;
    }
}