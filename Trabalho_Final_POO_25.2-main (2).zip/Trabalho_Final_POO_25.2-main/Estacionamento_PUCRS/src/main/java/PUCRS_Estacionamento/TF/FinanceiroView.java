package PUCRS_Estacionamento.TF;

import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.combobox.ComboBox;
import com.vaadin.flow.component.html.H2;
import com.vaadin.flow.component.html.H3;
import com.vaadin.flow.component.html.Hr;
import com.vaadin.flow.component.notification.Notification;
import com.vaadin.flow.component.notification.NotificationVariant;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.textfield.NumberField;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.router.RouterLink;

@PageTitle("Módulo Financeiro")
@Route("financeiro")
public class FinanceiroView extends VerticalLayout {

    private final ServicoDeEstacionamento servico = ServicoDeEstacionamento.getInstance();

    public FinanceiroView() {
        add(new H2("Módulo Financeiro"));

        add(new H3("Adicionar Créditos (Estudante)"));
        TextField cpfEstudante = new TextField("CPF do Estudante");
        ComboBox<Integer> valorCredito = new ComboBox<>("Valor (R$)");
        valorCredito.setItems(15, 50, 100, 150);
        Button btnCredito = new Button("Adicionar Créditos");
        btnCredito.addClickListener(e -> adicionarCredito(cpfEstudante.getValue(), valorCredito.getValue()));

        add(cpfEstudante, valorCredito, btnCredito);
        add(new Hr());

        add(new H3("Gerenciar Débitos (Tecnopuc)"));
        TextField cpfTecnopuc = new TextField("CPF da Empresa (Tecnopuc)");
        TextField debitoAtual = new TextField("Débito Atual (R$)");
        debitoAtual.setReadOnly(true);
        NumberField valorPago = new NumberField("Valor a Pagar (R$)");
        
        Button btnVerificar = new Button("Verificar Débito");
        btnVerificar.addClickListener(e -> {
            double debito = servico.getDebitoTecnopuc(cpfTecnopuc.getValue());
            if (debito == -1) {
                notificar("Cliente não é do Tecnopuc ou não foi encontrado.", true);
                debitoAtual.clear();
            } else {
                debitoAtual.setValue(String.format("%.2f", debito));
            }
        });

        Button btnPagar = new Button("Registrar Pagamento");
        btnPagar.addClickListener(e -> registrarPagamento(cpfTecnopuc.getValue(), valorPago.getValue(), debitoAtual));

        add(cpfTecnopuc, btnVerificar, debitoAtual, valorPago, btnPagar);
        add(new Hr(), new RouterLink("Voltar ao Menu", MainView.class));
        
        setPadding(true);
    }

    private void adicionarCredito(String cpf, Integer valor) {
        if (cpf.isEmpty() || valor == null) {
            notificar("CPF e Valor são obrigatórios.", true);
            return;
        }
        if (servico.adicionarCreditosEstudante(cpf, valor)) {
            notificar("Créditos adicionados com sucesso!", false);
        } else {
            notificar("Erro: CPF não encontrado ou não é Estudante.", true);
        }
    }

    private void registrarPagamento(String cpf, Double valor, TextField debitoAtualField) {
         if (cpf.isEmpty() || valor == null || valor <= 0) {
            notificar("CPF e Valor válido são obrigatórios.", true);
            return;
        }
        servico.registrarPagamentoTecnopuc(cpf, valor);
        notificar("Pagamento registrado.", false);
        double novoDebito = servico.getDebitoTecnopuc(cpf);
        debitoAtualField.setValue(String.format("%.2f", novoDebito));
    }

    private void notificar(String mensagem, boolean erro) {
        Notification notification = Notification.show(mensagem, 3000, Notification.Position.TOP_CENTER);
        if (erro) notification.addThemeVariants(NotificationVariant.LUMO_ERROR);
    }
}