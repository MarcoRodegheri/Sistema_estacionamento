package PUCRS_Estacionamento.TF;

import com.vaadin.flow.component.html.H1;
import com.vaadin.flow.component.html.Hr;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.router.RouterLink;

@Route("")
public class MainView extends VerticalLayout {
    public MainView() {
        add(new H1("Trabalho Final POO - Estacionamento PUCRS"));
        
        add(new RouterLink("Operação do Estacionamento (Entrada/Saída)", OperacaoView.class));
        add(new Hr());
        add(new RouterLink("Módulo Financeiro (Créditos/Débitos)", FinanceiroView.class));
        add(new Hr());
        add(new RouterLink("Módulo Gerencial (Relatórios)", RelatoriosView.class));

        setAlignItems(Alignment.CENTER);
        setPadding(true);
    }
}